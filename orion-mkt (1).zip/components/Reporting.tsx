
import React, { useState, useMemo } from 'react';
import { BusinessData, TimeRange } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Calendar, Download, Filter } from 'lucide-react';

interface Props {
  data: BusinessData;
}

const Reporting: React.FC<Props> = ({ data }) => {
  const [range, setRange] = useState<TimeRange>('monthly');

  const filteredMetrics = useMemo(() => {
    const now = Date.now();
    const dayMs = 24 * 60 * 60 * 1000;
    
    let threshold = 0;
    if (range === 'daily') threshold = now - dayMs;
    if (range === 'weekly') threshold = now - (dayMs * 7);
    if (range === 'monthly') threshold = now - (dayMs * 30);
    if (range === 'annual') threshold = now - (dayMs * 365);

    const sales = data.sales.filter(s => s.date >= threshold);
    const expenses = data.expenses.filter(e => e.date >= threshold);

    const grossSales = sales.reduce((sum, s) => sum + s.totalAmount, 0);
    const cogs = sales.reduce((sum, s) => sum + (s.costPrice * s.quantity), 0);
    const grossProfit = grossSales - cogs;
    const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
    const netProfit = grossProfit - totalExpenses;

    return { grossSales, grossProfit, totalExpenses, netProfit };
  }, [data, range]);

  const expenseByCategory = useMemo(() => {
    const map: Record<string, number> = {};
    data.expenses.forEach(e => {
      map[e.category] = (map[e.category] || 0) + e.amount;
    });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [data]);

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-200">
        <div className="flex items-center gap-4">
          <Calendar className="text-blue-600" />
          <h3 className="font-bold text-slate-800">Financial Performance Analysis</h3>
        </div>
        <div className="flex items-center gap-2 bg-slate-50 p-1 rounded-xl">
          {(['daily', 'weekly', 'monthly', 'annual'] as TimeRange[]).map(r => (
            <button 
              key={r}
              onClick={() => setRange(r)}
              className={`px-4 py-1.5 rounded-lg text-sm font-bold capitalize transition-all ${
                range === r ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {[
          { label: 'Gross Sales', val: filteredMetrics.grossSales, color: 'text-blue-600' },
          { label: 'Gross Profit', val: filteredMetrics.grossProfit, color: 'text-emerald-600' },
          { label: 'Total Expenditure', val: filteredMetrics.totalExpenses, color: 'text-orange-600' },
          { label: 'Net Performance', val: filteredMetrics.netProfit, color: filteredMetrics.netProfit >= 0 ? 'text-indigo-600' : 'text-red-600' },
        ].map((m, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl border border-slate-200 text-center">
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">{m.label}</p>
            <h4 className={`text-2xl font-black ${m.color}`}>
              ${m.val.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </h4>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
          <h4 className="text-lg font-bold mb-8">Expenditure Breakdown</h4>
          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={expenseByCategory}
                  cx="50%"
                  cy="50%"
                  innerRadius={80}
                  outerRadius={120}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {expenseByCategory.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend layout="vertical" verticalAlign="middle" align="right" />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
          <h4 className="text-lg font-bold mb-8">Stock vs Sales Activity</h4>
          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={[{ name: 'Metrics', Sales: filteredMetrics.grossSales, Profit: filteredMetrics.grossProfit, Expenses: filteredMetrics.totalExpenses }]}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" hide />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="Sales" fill="#3b82f6" radius={[6, 6, 0, 0]} />
                <Bar dataKey="Profit" fill="#10b981" radius={[6, 6, 0, 0]} />
                <Bar dataKey="Expenses" fill="#f59e0b" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reporting;
