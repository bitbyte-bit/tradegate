
import React, { useState } from 'react';
import { StockItem } from '../types';
import { Plus, Search, Edit2, Trash2, PackagePlus } from 'lucide-react';

interface Props {
  stock: StockItem[];
  onUpdate: (stock: StockItem[]) => void;
}

const StockManager: React.FC<Props> = ({ stock, onUpdate }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [newItem, setNewItem] = useState<Partial<StockItem>>({
    name: '',
    category: '',
    costPrice: 0,
    sellingPrice: 0,
    quantity: 0
  });

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const item: StockItem = {
      id: crypto.randomUUID(),
      name: newItem.name || 'Unnamed Item',
      category: newItem.category || 'General',
      costPrice: newItem.costPrice || 0,
      sellingPrice: newItem.sellingPrice || 0,
      quantity: newItem.quantity || 0,
      lastUpdated: Date.now()
    };
    onUpdate([...stock, item]);
    setIsAdding(false);
    setNewItem({ name: '', category: '', costPrice: 0, sellingPrice: 0, quantity: 0 });
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this item?')) {
      onUpdate(stock.filter(i => i.id !== id));
    }
  };

  const filteredStock = stock.filter(item => 
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Search products..."
            className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="flex items-center justify-center gap-2 bg-blue-600 text-white px-5 py-2.5 rounded-xl font-semibold hover:bg-blue-700 transition-colors shadow-sm"
        >
          <Plus size={20} />
          Add Item
        </button>
      </div>

      {isAdding && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm animate-in slide-in-from-top-4 duration-300">
          <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
            <PackagePlus className="text-blue-600" />
            Add New Product
          </h3>
          <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Product Name</label>
              <input 
                required
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                value={newItem.name}
                onChange={e => setNewItem({ ...newItem, name: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Category</label>
              <input 
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                value={newItem.category}
                onChange={e => setNewItem({ ...newItem, category: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Stock Quantity</label>
              <input 
                type="number"
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                value={newItem.quantity}
                onChange={e => setNewItem({ ...newItem, quantity: parseInt(e.target.value) || 0 })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Cost Price (Purchase)</label>
              <input 
                type="number" step="0.01"
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                value={newItem.costPrice}
                onChange={e => setNewItem({ ...newItem, costPrice: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Selling Price</label>
              <input 
                type="number" step="0.01"
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                value={newItem.sellingPrice}
                onChange={e => setNewItem({ ...newItem, sellingPrice: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div className="flex items-end gap-3">
              <button type="submit" className="flex-1 bg-blue-600 text-white py-2 rounded-lg font-bold">Save</button>
              <button type="button" onClick={() => setIsAdding(false)} className="px-4 py-2 bg-slate-100 text-slate-600 rounded-lg font-bold">Cancel</button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50 text-slate-500 text-xs font-bold uppercase tracking-wider">
              <tr>
                <th className="px-6 py-4">Item Name</th>
                <th className="px-6 py-4">Category</th>
                <th className="px-6 py-4">Stock</th>
                <th className="px-6 py-4">Cost</th>
                <th className="px-6 py-4">Selling</th>
                <th className="px-6 py-4">Pot. Profit</th>
                <th className="px-6 py-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStock.map(item => (
                <tr key={item.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4 font-semibold text-slate-800">{item.name}</td>
                  <td className="px-6 py-4 text-slate-500">{item.category}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-md text-xs font-bold ${item.quantity < 5 ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600'}`}>
                      {item.quantity} units
                    </span>
                  </td>
                  <td className="px-6 py-4 text-slate-600">${item.costPrice.toFixed(2)}</td>
                  <td className="px-6 py-4 text-slate-900 font-bold">${item.sellingPrice.toFixed(2)}</td>
                  <td className="px-6 py-4 text-emerald-600 font-medium">
                    +${((item.sellingPrice - item.costPrice) * item.quantity).toFixed(2)}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex justify-center gap-2">
                      <button className="p-1.5 text-slate-400 hover:text-blue-600 transition-colors"><Edit2 size={16} /></button>
                      <button onClick={() => handleDelete(item.id)} className="p-1.5 text-slate-400 hover:text-red-600 transition-colors"><Trash2 size={16} /></button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredStock.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-slate-400 font-medium">
                    No products found. Start by adding a new item.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default StockManager;
