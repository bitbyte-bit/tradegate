
import React, { useState } from 'react';
import { ExpenseRecord } from '../types';
import { ReceiptIndianRupee, Plus, Calendar, Tag, Trash2 } from 'lucide-react';

interface Props {
  expenses: ExpenseRecord[];
  onUpdate: (expenses: ExpenseRecord[]) => void;
}

const ExpenseTracker: React.FC<Props> = ({ expenses, onUpdate }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newExp, setNewExp] = useState<Partial<ExpenseRecord>>({
    category: '',
    amount: 0,
    description: ''
  });

  const categories = ['Rent', 'Utilities', 'Salaries', 'Supplies', 'Transport', 'Marketing', 'Maintenance', 'Other'];

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const exp: ExpenseRecord = {
      id: crypto.randomUUID(),
      category: newExp.category || 'Other',
      amount: newExp.amount || 0,
      description: newExp.description || '',
      date: Date.now()
    };
    onUpdate([...expenses, exp]);
    setIsAdding(false);
    setNewExp({ category: '', amount: 0, description: '' });
  };

  const handleDelete = (id: string) => {
    onUpdate(expenses.filter(e => e.id !== id));
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-bold text-slate-800">Expenditure Tracker</h3>
          <p className="text-sm text-slate-500">Manage business overheads and operational costs</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-orange-600 text-white px-5 py-2.5 rounded-xl font-bold hover:bg-orange-700 flex items-center gap-2"
        >
          <Plus size={20} />
          Record Expense
        </button>
      </div>

      {isAdding && (
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-xl max-w-2xl mx-auto">
          <h4 className="text-lg font-bold mb-6">Log New Expense</h4>
          <form onSubmit={handleAdd} className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold mb-2">Category</label>
                <select 
                  required
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                  value={newExp.category}
                  onChange={e => setNewExp({...newExp, category: e.target.value})}
                >
                  <option value="">Select category...</option>
                  {categories.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">Amount ($)</label>
                <input 
                  type="number" step="0.01" required
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                  value={newExp.amount}
                  onChange={e => setNewExp({...newExp, amount: parseFloat(e.target.value) || 0})}
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-semibold mb-2">Description</label>
              <textarea 
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none h-24"
                placeholder="What was this for?"
                value={newExp.description}
                onChange={e => setNewExp({...newExp, description: e.target.value})}
              />
            </div>
            <div className="flex gap-3 pt-2">
              <button type="submit" className="flex-1 bg-orange-600 text-white py-3 rounded-xl font-bold">Record Expense</button>
              <button type="button" onClick={() => setIsAdding(false)} className="px-6 bg-slate-100 rounded-xl">Cancel</button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {expenses.slice().reverse().map(exp => (
          <div key={exp.id} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative group">
            <button 
              onClick={() => handleDelete(exp.id)}
              className="absolute top-4 right-4 text-slate-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
            >
              <Trash2 size={18} />
            </button>
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-orange-50 p-3 rounded-xl text-orange-600">
                <Tag size={20} />
              </div>
              <div>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">{exp.category}</p>
                <h4 className="text-xl font-black text-slate-800">${exp.amount.toFixed(2)}</h4>
              </div>
            </div>
            <p className="text-slate-600 text-sm mb-4 italic">"{exp.description || 'No details provided'}"</p>
            <div className="flex items-center gap-2 text-xs text-slate-400 font-medium pt-4 border-t border-slate-50">
              <Calendar size={14} />
              {new Date(exp.date).toLocaleDateString()}
            </div>
          </div>
        ))}
        {expenses.length === 0 && (
          <div className="col-span-full py-20 text-center text-slate-400 font-medium">
            No expenses recorded yet.
          </div>
        )}
      </div>
    </div>
  );
};

export default ExpenseTracker;
