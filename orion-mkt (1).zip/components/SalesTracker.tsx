
import React, { useState } from 'react';
import { BusinessData, SaleRecord, StockItem } from '../types';
import { ShoppingCart, Package, DollarSign, Plus, History } from 'lucide-react';

interface Props {
  data: BusinessData;
  onUpdate: (sales: SaleRecord[], stock: StockItem[]) => void;
}

const SalesTracker: React.FC<Props> = ({ data, onUpdate }) => {
  const [selectedId, setSelectedId] = useState('');
  const [qty, setQty] = useState(1);
  const [isRecording, setIsRecording] = useState(false);

  const handleSale = (e: React.FormEvent) => {
    e.preventDefault();
    const item = data.stock.find(s => s.id === selectedId);
    if (!item) return;
    if (item.quantity < qty) {
      alert('Insufficient stock!');
      return;
    }

    const sale: SaleRecord = {
      id: crypto.randomUUID(),
      itemId: item.id,
      itemName: item.name,
      quantity: qty,
      unitPrice: item.sellingPrice,
      costPrice: item.costPrice,
      totalAmount: item.sellingPrice * qty,
      date: Date.now()
    };

    const newStock = data.stock.map(s => 
      s.id === item.id ? { ...s, quantity: s.quantity - qty } : s
    );

    onUpdate([...data.sales, sale], newStock);
    setSelectedId('');
    setQty(1);
    setIsRecording(false);
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
          <ShoppingCart className="text-blue-600" />
          Point of Sale
        </h3>
        <button 
          onClick={() => setIsRecording(true)}
          className="bg-blue-600 text-white px-6 py-2.5 rounded-xl font-bold hover:bg-blue-700 transition-all flex items-center gap-2"
        >
          <Plus size={20} />
          Record New Sale
        </button>
      </div>

      {isRecording && (
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-xl max-w-2xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h4 className="text-lg font-bold">New Transaction</h4>
            <button onClick={() => setIsRecording(false)} className="text-slate-400 hover:text-slate-600">✕</button>
          </div>
          <form onSubmit={handleSale} className="space-y-6">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Select Product</label>
              <select 
                required
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                value={selectedId}
                onChange={e => setSelectedId(e.target.value)}
              >
                <option value="">Choose an item...</option>
                {data.stock.map(item => (
                  <option key={item.id} value={item.id} disabled={item.quantity <= 0}>
                    {item.name} (${item.sellingPrice.toFixed(2)}) - {item.quantity} available
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Quantity</label>
                <input 
                  type="number" 
                  min="1"
                  required
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                  value={qty}
                  onChange={e => setQty(parseInt(e.target.value) || 1)}
                />
              </div>
              <div className="flex flex-col justify-end">
                <p className="text-xs text-slate-500 font-medium mb-1 uppercase tracking-wider">Total Charge</p>
                <p className="text-3xl font-black text-slate-900">
                  ${((data.stock.find(s => s.id === selectedId)?.sellingPrice || 0) * qty).toFixed(2)}
                </p>
              </div>
            </div>

            <button 
              type="submit" 
              className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-blue-700 shadow-lg shadow-blue-200 transition-all"
            >
              Confirm Sale
            </button>
          </form>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="p-6 border-b border-slate-100 flex items-center gap-2">
          <History size={20} className="text-slate-400" />
          <h4 className="font-bold text-slate-800">Recent Transactions</h4>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-500 text-xs font-bold uppercase tracking-wider">
              <tr>
                <th className="px-6 py-4">Time</th>
                <th className="px-6 py-4">Item</th>
                <th className="px-6 py-4 text-center">Qty</th>
                <th className="px-6 py-4">Total Price</th>
                <th className="px-6 py-4">Margin</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {data.sales.slice().reverse().map(sale => (
                <tr key={sale.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4 text-slate-500 text-sm">
                    {new Date(sale.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </td>
                  <td className="px-6 py-4 font-semibold text-slate-800">{sale.itemName}</td>
                  <td className="px-6 py-4 text-center text-slate-600">{sale.quantity}</td>
                  <td className="px-6 py-4 font-bold text-slate-900">${sale.totalAmount.toFixed(2)}</td>
                  <td className="px-6 py-4 text-emerald-600 font-medium">
                    +${(sale.totalAmount - (sale.costPrice * sale.quantity)).toFixed(2)}
                  </td>
                </tr>
              ))}
              {data.sales.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-slate-400">
                    No sales recorded yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default SalesTracker;
