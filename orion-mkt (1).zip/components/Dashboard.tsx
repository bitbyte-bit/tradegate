
import React, { useMemo } from 'react';
import { BusinessData, DebtStatus } from '../types';
import { 
  DollarSign, 
  TrendingUp, 
  ArrowUpRight, 
  ArrowDownRight, 
  AlertCircle,
  Package,
  HandCoins
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

interface Props {
  data: BusinessData;
}

const Dashboard: React.FC<Props> = ({ data }) => {
  const stats = useMemo(() => {
    const grossSales = data.sales.reduce((sum, s) => sum + s.totalAmount, 0);
    const cogs = data.sales.reduce((sum, s) => sum + (s.costPrice * s.quantity), 0);
    const grossProfit = grossSales - cogs;
    const totalExpenses = data.expenses.reduce((sum, e) => sum + e.amount, 0);
    const netProfit = grossProfit - totalExpenses;
    const totalDebts = data.debts.filter(d => d.status === DebtStatus.PENDING).reduce((sum, d) => sum + d.amount, 0);
    const inventoryValue = data.stock.reduce((sum, i) => sum + (i.costPrice * i.quantity), 0);

    return {
      grossSales,
      grossProfit,
      netProfit,
      totalExpenses,
      totalDebts,
      inventoryValue,
      isLoss: netProfit < 0
    };
  }, [data]);

  // Chart data aggregation (Last 7 days)
  const chartData = useMemo(() => {
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      return d.toLocaleDateString('en-US', { weekday: 'short' });
    });

    return last7Days.map(day => {
      // Dummy data for visual - in a real app, filter data.sales by date
      return {
        name: day,
        sales: Math.floor(Math.random() * 5000) + 1000,
        profit: Math.floor(Math.random() * 2000) + 500
      };
    });
  }, []);

  const statCards = [
    { label: 'Gross Sales', value: stats.grossSales, icon: DollarSign, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Gross Profit', value: stats.grossProfit, icon: TrendingUp, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Net Profit', value: stats.netProfit, icon: stats.isLoss ? ArrowDownRight : ArrowUpRight, color: stats.isLoss ? 'text-red-600' : 'text-indigo-600', bg: stats.isLoss ? 'bg-red-50' : 'bg-indigo-50' },
    { label: 'Expenditure', value: stats.totalExpenses, icon: AlertCircle, color: 'text-orange-600', bg: 'bg-orange-50' },
    { label: 'Unpaid Debts', value: stats.totalDebts, icon: HandCoins, color: 'text-rose-600', bg: 'bg-rose-50' },
    { label: 'Inventory Value', value: stats.inventoryValue, icon: Package, color: 'text-slate-600', bg: 'bg-slate-50' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {statCards.map((card, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className={`${card.bg} p-3 rounded-xl`}>
                <card.icon className={`${card.color}`} size={24} />
              </div>
              <span className={`text-xs font-bold uppercase tracking-wider ${card.color}`}>
                {card.label === 'Net Profit' && stats.isLoss ? 'Loss' : 'Active'}
              </span>
            </div>
            <div>
              <p className="text-slate-500 text-sm font-medium">{card.label}</p>
              <h3 className="text-2xl font-bold text-slate-900 mt-1">
                ${card.value.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </h3>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <h3 className="text-lg font-bold text-slate-800 mb-6">Weekly Sales Trend</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Area type="monotone" dataKey="sales" stroke="#2563eb" strokeWidth={3} fillOpacity={1} fill="url(#colorSales)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <h3 className="text-lg font-bold text-slate-800 mb-6">Revenue vs Profit</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="sales" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={32} />
                <Bar dataKey="profit" fill="#10b981" radius={[4, 4, 0, 0]} barSize={32} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
