
import React, { useState } from 'react';
import { DebtRecord, DebtStatus } from '../types';
import { HandCoins, UserPlus, CheckCircle2, AlertCircle, Trash2 } from 'lucide-react';

interface Props {
  debts: DebtRecord[];
  onUpdate: (debts: DebtRecord[]) => void;
}

const DebtManager: React.FC<Props> = ({ debts, onUpdate }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newDebt, setNewDebt] = useState<Partial<DebtRecord>>({
    customerName: '',
    amount: 0,
    description: ''
  });

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const debt: DebtRecord = {
      id: crypto.randomUUID(),
      customerName: newDebt.customerName || 'Anonymous',
      amount: newDebt.amount || 0,
      description: newDebt.description || '',
      status: DebtStatus.PENDING,
      date: Date.now()
    };
    onUpdate([...debts, debt]);
    setIsAdding(false);
    setNewDebt({ customerName: '', amount: 0, description: '' });
  };

  const updateStatus = (id: string, status: DebtStatus) => {
    onUpdate(debts.map(d => d.id === id ? { ...d, status } : d));
  };

  const handleDelete = (id: string) => {
    onUpdate(debts.filter(d => d.id !== id));
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold text-slate-800">Accounts Receivable</h3>
          <p className="text-sm text-slate-500">Track money owed to your business</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-bold hover:bg-indigo-700 flex items-center gap-2"
        >
          <UserPlus size={20} />
          New Debt Record
        </button>
      </div>

      {isAdding && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm animate-in slide-in-from-top-4">
          <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium mb-1">Customer Name</label>
              <input 
                required
                className="w-full px-4 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-indigo-500"
                value={newDebt.customerName}
                onChange={e => setNewDebt({...newDebt, customerName: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Amount Owed ($)</label>
              <input 
                type="number" step="0.01" required
                className="w-full px-4 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-indigo-500"
                value={newDebt.amount}
                onChange={e => setNewDebt({...newDebt, amount: parseFloat(e.target.value) || 0})}
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium mb-1">Description / Items Borrowed</label>
              <textarea 
                className="w-full px-4 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-indigo-500"
                value={newDebt.description}
                onChange={e => setNewDebt({...newDebt, description: e.target.value})}
              />
            </div>
            <div className="flex gap-2">
              <button type="submit" className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-bold">Save Record</button>
              <button type="button" onClick={() => setIsAdding(false)} className="bg-slate-100 px-6 py-2 rounded-lg">Cancel</button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {debts.length === 0 && <p className="text-slate-400 py-10 col-span-full text-center">No debt records found.</p>}
        {debts.slice().reverse().map(debt => (
          <div 
            key={debt.id} 
            className={`p-5 rounded-2xl border-2 transition-all ${
              debt.status === DebtStatus.PENDING ? 'bg-red-50 border-red-200' : 
              debt.status === DebtStatus.PAID ? 'bg-emerald-50 border-emerald-200 opacity-75' : 
              'bg-slate-100 border-slate-300 grayscale'
            }`}
          >
            <div className="flex justify-between items-start mb-4">
              <div>
                <h4 className="font-black text-slate-800 text-lg uppercase tracking-tight">{debt.customerName}</h4>
                <p className="text-xs text-slate-500 font-medium">
                  Recorded: {new Date(debt.date).toLocaleDateString()}
                </p>
              </div>
              <div className={`text-2xl font-black ${debt.status === DebtStatus.PENDING ? 'text-red-600' : 'text-slate-600'}`}>
                ${debt.amount.toFixed(2)}
              </div>
            </div>
            
            <p className="text-sm text-slate-600 mb-6 min-h-[40px]">
              {debt.description || 'No description provided.'}
            </p>

            <div className="flex items-center gap-2">
              {debt.status === DebtStatus.PENDING && (
                <>
                  <button 
                    onClick={() => updateStatus(debt.id, DebtStatus.PAID)}
                    className="flex-1 flex items-center justify-center gap-1 bg-emerald-600 text-white py-2 rounded-lg text-sm font-bold"
                  >
                    <CheckCircle2 size={14} /> Mark Paid
                  </button>
                  <button 
                    onClick={() => updateStatus(debt.id, DebtStatus.BAD_DEBT)}
                    className="flex-1 flex items-center justify-center gap-1 bg-slate-800 text-white py-2 rounded-lg text-sm font-bold"
                  >
                    <AlertCircle size={14} /> Bad Debt
                  </button>
                </>
              )}
              {debt.status !== DebtStatus.PENDING && (
                <div className="flex-1 text-center py-2 font-black uppercase text-xs tracking-widest text-slate-500">
                  {debt.status === DebtStatus.PAID ? '✓ Fully Cleared' : '✕ Written Off'}
                </div>
              )}
              <button 
                onClick={() => handleDelete(debt.id)}
                className="p-2 text-slate-400 hover:text-red-600 transition-colors"
              >
                <Trash2 size={18} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DebtManager;
